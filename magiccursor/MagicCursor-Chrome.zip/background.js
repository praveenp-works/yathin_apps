// Magic Cursor for Chrome - background service worker
const MODELS = ["gemini-3.5-flash-lite", "gemini-3.8-flash", "gemini-3.6-flash",
                "gemini-flash-lite-latest", "gemini-flash-latest"];

const SYSTEM = "You are Magic Cursor, an AI helper powered by Google Gemini, built into the user's browser. " +
  "You can search Google and read web links, so use them for current facts or anything you are unsure of. " +
  "Any image is the part of their screen they selected. Answer clearly, naturally and helpfully, with a calm, " +
  "neutral tone. Don't gush or flatter. Give a full answer with a few headings, bullet points and bold where they help; " +
  "keep it short only if asked or if it is a one-word fact. Start directly with the answer, don't restate the question. " +
  "At most one short next-step suggestion, and only things you can do in this chat (explain, summarize, translate, " +
  "rewrite, solve, look things up), never clicking, opening or controlling the computer. " +
  "MOST IMPORTANT: answer exactly what the user typed. Use the screenshot only as context when their question is about it. " +
  "If they give no real question, briefly say what the screenshot shows and the most useful thing about it. " +
  "If the user appears to be a student asking for homework answers, help them understand and learn the steps.";

let webOk = true;
let goodModel = null;

async function start(tab) {
  if (!tab || !tab.id) return;
  let shot;
  try {
    shot = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
  } catch (e) {
    shot = null;
  }
  try {
    await chrome.scripting.insertCSS({ target: { tabId: tab.id }, files: ["content.css"] });
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    chrome.tabs.sendMessage(tab.id, { type: "mc-start", shot });
  } catch (e) {
    // Chrome pages (chrome://, Web Store, new tab) don't allow extensions.
    chrome.action.setBadgeText({ tabId: tab.id, text: "!" });
    chrome.action.setTitle({ tabId: tab.id, title: "Magic Cursor can't run on this page. Try a normal website." });
  }
}

chrome.action.onClicked.addListener(start);

chrome.runtime.onInstalled.addListener(async (d) => {
  const { key } = await chrome.storage.local.get("key");
  if (!key && d.reason === "install") chrome.runtime.openOptionsPage();
});

chrome.runtime.onMessage.addListener((m) => {
  if (m && m.type === "mc-options") chrome.runtime.openOptionsPage();
});

// Streaming chat over a port: {contents} in, {t:text} chunks out, then {done} or {error}
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "mc-chat") return;
  port.onMessage.addListener(async (m) => {
    const { key } = await chrome.storage.local.get("key");
    if (!key) { port.postMessage({ error: "nokey" }); return; }
    try {
      await ask(key, m.contents, (t) => port.postMessage({ t }));
      port.postMessage({ done: true });
    } catch (e) {
      port.postMessage({ error: String(e.message || e) });
    }
  });
});

async function ask(key, contents, onText) {
  const models = goodModel ? [goodModel, ...MODELS.filter((x) => x !== goodModel)] : MODELS;
  let lastErr = "No model worked";
  for (const model of models) {
    for (const web of webOk ? [true, false] : [false]) {
      const body = { contents, systemInstruction: { parts: [{ text: SYSTEM }] } };
      if (web) body.tools = [{ google_search: {} }, { url_context: {} }];
      const r = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?alt=sse`,
        { method: "POST", headers: { "Content-Type": "application/json", "x-goog-api-key": key }, body: JSON.stringify(body) });
      if (!r.ok) {
        const txt = await r.text();
        lastErr = r.status === 400 && /API key/i.test(txt) ? "badkey" : `Gemini error ${r.status}`;
        if (lastErr === "badkey") throw new Error("badkey");
        if (r.status === 404) break;          // model not available: next model
        if (web && r.status === 400) { webOk = false; continue; } // tools rejected: retry plain
        if (r.status === 429) lastErr = "busy";
        break;
      }
      goodModel = model;
      const reader = r.body.getReader();
      const dec = new TextDecoder();
      let buf = "";
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buf += dec.decode(value, { stream: true });
        let i;
        while ((i = buf.indexOf("\n")) >= 0) {
          const line = buf.slice(0, i).trim();
          buf = buf.slice(i + 1);
          if (!line.startsWith("data:")) continue;
          try {
            const j = JSON.parse(line.slice(5));
            const parts = j.candidates?.[0]?.content?.parts || [];
            for (const p of parts) if (p.text && !p.thought) onText(p.text);
          } catch (_) {}
        }
      }
      return;
    }
  }
  throw new Error(lastErr);
}
