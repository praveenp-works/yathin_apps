// Magic Cursor for Chrome - on-page overlay: select an area, then chat with Gemini about it.
(() => {
  if (window.__magicCursorLoaded) return;
  window.__magicCursorLoaded = true;

  const COLORS = ["#4285f4", "#ea4335", "#fbbc04", "#34a853"];
  const RAINBOW = `conic-gradient(from var(--a), ${COLORS.join(",")}, ${COLORS[0]})`;
  let host, root, state = null;

  const CSS = `
  @property --a { syntax: '<angle>'; initial-value: 0deg; inherits: false; }
  @keyframes spin { to { --a: 360deg; } }
  @keyframes fadein { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }
  * { box-sizing: border-box; font-family: "Poppins", "Segoe UI", Roboto, Arial, sans-serif; }
  .shade { position: fixed; inset: 0; cursor: crosshair; pointer-events: auto; background: rgba(10,12,20,.28); }
  .hint { position: fixed; top: 18px; left: 50%; transform: translateX(-50%); background: #1f2230; color: #fff;
          padding: 9px 16px; border-radius: 999px; font-size: 13px; pointer-events: none; box-shadow: 0 6px 24px rgba(0,0,0,.35); }
  .sel { position: fixed; border-radius: 10px; pointer-events: none; padding: 3px;
         background: ${RAINBOW}; animation: spin 2.2s linear infinite;
         -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0); -webkit-mask-composite: xor; mask-composite: exclude; }
  .panel { position: fixed; width: 400px; max-height: min(560px, 80vh); display: flex; flex-direction: column;
           background: #171923; color: #e8eaf2; border-radius: 18px; pointer-events: auto; overflow: hidden;
           box-shadow: 0 18px 50px rgba(0,0,0,.45); animation: fadein .18s ease-out; font-size: 14px; }
  .panel::before { content: ""; position: absolute; inset: 0; border-radius: 18px; padding: 2px; pointer-events: none;
           background: ${RAINBOW}; animation: spin 3s linear infinite;
           -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0); -webkit-mask-composite: xor; mask-composite: exclude; }
  .head { display: flex; align-items: center; gap: 8px; padding: 12px 14px 8px; cursor: move; user-select: none; }
  .head img { width: 22px; height: 22px; border-radius: 6px; }
  .head b { flex: 1; font-size: 14px; background: linear-gradient(90deg,#6b95ff,#8f78ff,#a86bf2); -webkit-background-clip: text; color: transparent; }
  .ib { background: none; border: 0; color: #9aa0b4; font-size: 16px; cursor: pointer; padding: 4px 6px; border-radius: 8px; }
  .ib:hover { background: #262a38; color: #fff; }
  .thumb { margin: 0 14px 6px; max-height: 90px; border-radius: 10px; object-fit: cover; object-position: top; border: 1px solid #2c3040; }
  .chat { flex: 1; overflow-y: auto; padding: 4px 14px 8px; scroll-behavior: smooth; }
  .msg { margin: 8px 0; line-height: 1.55; word-wrap: break-word; }
  .me { background: #2a2f45; padding: 8px 12px; border-radius: 14px 14px 4px 14px; margin-left: 40px; }
  .ai h1,.ai h2,.ai h3 { font-size: 15px; margin: 10px 0 4px; color: #fff; }
  .ai p { margin: 6px 0; } .ai ul,.ai ol { margin: 4px 0; padding-left: 20px; }
  .ai code { background: #262a38; padding: 1px 5px; border-radius: 5px; font-family: Consolas, monospace; font-size: 13px; }
  .ai pre { background: #0f1118; padding: 10px; border-radius: 10px; overflow-x: auto; }
  .ai pre code { background: none; padding: 0; }
  .ai a { color: #8ab4f8; }
  .dots span { display: inline-block; width: 7px; height: 7px; margin-right: 4px; border-radius: 50%; animation: b 1s infinite; }
  .dots span:nth-child(1){background:#4285f4}.dots span:nth-child(2){background:#ea4335;animation-delay:.15s}.dots span:nth-child(3){background:#fbbc04;animation-delay:.3s}
  @keyframes b { 50% { transform: translateY(-5px); opacity: .5; } }
  .err { color: #ffb4ab; }
  .row { display: flex; gap: 8px; padding: 10px 12px 12px; border-top: 1px solid #262a38; }
  .row textarea { flex: 1; resize: none; background: #222533; color: #fff; border: 1px solid #333849; border-radius: 12px;
                  padding: 9px 12px; font-size: 14px; outline: none; max-height: 110px; }
  .row textarea:focus { border-color: #6b95ff; }
  .send { background: linear-gradient(135deg,#6b95ff,#a86bf2); border: 0; color: #fff; width: 38px; border-radius: 12px; cursor: pointer; font-size: 16px; }
  .setup { padding: 10px 14px 16px; line-height: 1.5; }
  .btn { display: inline-block; margin-top: 8px; background: linear-gradient(135deg,#6b95ff,#a86bf2); color: #fff; border: 0;
         padding: 8px 14px; border-radius: 10px; cursor: pointer; font-size: 13px; }
  `;

  function el(tag, cls, html) { const e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; }

  function close() {
    if (host) host.remove();
    host = root = state = null;
    document.removeEventListener("keydown", onKey, true);
  }
  function onKey(e) { if (e.key === "Escape") { e.stopPropagation(); close(); } }

  function mount() {
    close();
    host = el("div"); host.id = "magic-cursor-host";
    host.style.cssText = "all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none;";
    root = host.attachShadow({ mode: "closed" });
    root.appendChild(el("style", null, CSS));
    document.documentElement.appendChild(host);
    document.addEventListener("keydown", onKey, true);
  }

  // ---------- Step 1: select an area ----------
  function startSelect(shot) {
    mount();
    const shade = el("div", "shade"), sel = el("div", "sel"), hint = el("div", "hint",
      "Drag to select an area · click to use the whole page · Esc to cancel");
    sel.style.display = "none";
    root.append(shade, sel, hint);
    let x0, y0, dragging = false;
    shade.addEventListener("mousedown", (e) => { x0 = e.clientX; y0 = e.clientY; dragging = true; sel.style.display = "block"; draw(e); e.preventDefault(); });
    shade.addEventListener("mousemove", (e) => dragging && draw(e));
    shade.addEventListener("mouseup", (e) => {
      if (!dragging) return; dragging = false;
      let r = rect(e);
      if (r.w < 8 || r.h < 8) r = { x: 0, y: 0, w: innerWidth, h: innerHeight };
      shade.remove(); hint.remove(); sel.remove();
      crop(shot, r).then((img) => openPanel(img, r));
    });
    function rect(e) { return { x: Math.min(x0, e.clientX), y: Math.min(y0, e.clientY), w: Math.abs(e.clientX - x0), h: Math.abs(e.clientY - y0) }; }
    function draw(e) { const r = rect(e); Object.assign(sel.style, { left: r.x - 3 + "px", top: r.y - 3 + "px", width: r.w + 6 + "px", height: r.h + 6 + "px" }); }
  }

  function crop(shot, r) {
    return new Promise((res) => {
      if (!shot) return res(null);
      const im = new Image();
      im.onload = () => {
        const s = im.width / innerWidth;
        const c = document.createElement("canvas");
        c.width = Math.round(r.w * s); c.height = Math.round(r.h * s);
        c.getContext("2d").drawImage(im, r.x * s, r.y * s, r.w * s, r.h * s, 0, 0, c.width, c.height);
        res(c.toDataURL("image/png"));
      };
      im.onerror = () => res(null);
      im.src = shot;
    });
  }

  // ---------- Step 2: chat panel ----------
  async function openPanel(img, r) {
    const panel = el("div", "panel");
    const head = el("div", "head");
    head.append(Object.assign(el("img"), { src: chrome.runtime.getURL("icons/icon48.png") }), el("b", null, "Magic Cursor"));
    const gear = el("button", "ib", "⚙"); gear.title = "Settings";
    gear.onclick = () => chrome.runtime.sendMessage({ type: "mc-options" });
    const x = el("button", "ib", "✕"); x.title = "Close (Esc)"; x.onclick = close;
    head.append(gear, x);
    panel.append(head);
    if (img) { const t = el("img", "thumb"); t.src = img; panel.append(t); }
    const chat = el("div", "chat");
    const row = el("div", "row");
    const ta = el("textarea"); ta.rows = 1; ta.placeholder = "Ask Magic Cursor about this…";
    const send = el("button", "send", "➤"); send.title = "Send";
    row.append(ta, send);
    panel.append(chat, row);
    root.appendChild(panel);
    place(panel, r);
    drag(panel, head);

    const { key } = await chrome.storage.local.get("key");
    if (!key) { setup(chat); }
    state = { img, history: [], busy: false };
    setTimeout(() => ta.focus(), 30);

    ta.addEventListener("input", () => { ta.style.height = "auto"; ta.style.height = Math.min(ta.scrollHeight, 110) + "px"; });
    ta.addEventListener("keydown", (e) => { e.stopPropagation(); if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); go(); } if (e.key === "Escape") close(); });
    ta.addEventListener("keyup", (e) => e.stopPropagation());
    ta.addEventListener("keypress", (e) => e.stopPropagation());
    send.onclick = go;

    function go() {
      const q = ta.value.trim();
      if (state.busy) return;
      ta.value = ""; ta.style.height = "auto";
      const parts = [];
      if (state.history.length === 0 && state.img) parts.push({ inline_data: { mime_type: "image/png", data: state.img.split(",")[1] } });
      parts.push({ text: q || "What is this?" });
      state.history.push({ role: "user", parts });
      chat.append(el("div", "msg me", esc(q || "What is this?")));
      const out = el("div", "msg ai", '<span class="dots"><span></span><span></span><span></span></span>');
      chat.append(out); chat.scrollTop = chat.scrollHeight;
      state.busy = true;
      let text = "";
      const port = chrome.runtime.connect({ name: "mc-chat" });
      port.onMessage.addListener((m) => {
        if (m.t) { text += m.t; const atEnd = chat.scrollHeight - chat.scrollTop - chat.clientHeight < 40; out.innerHTML = md(text); if (atEnd) chat.scrollTop = chat.scrollHeight; }
        if (m.done) { state.history.push({ role: "model", parts: [{ text }] }); state.busy = false; port.disconnect(); }
        if (m.error) {
          state.history.pop(); state.busy = false; port.disconnect();
          if (m.error === "nokey" || m.error === "badkey") { out.remove(); setup(chat, m.error === "badkey"); }
          else out.innerHTML = `<span class="err">${m.error === "busy" ? "Gemini is busy right now. Wait a moment and try again." : "Something went wrong: " + esc(m.error)}</span>`;
        }
      });
      port.postMessage({ contents: state.history });
    }
  }

  function setup(chat, bad) {
    const s = el("div", "setup",
      (bad ? "<b>That Gemini key didn't work.</b><br>" : "<b>One-time setup:</b> Magic Cursor needs a free Gemini key.<br>") +
      "Get one from Google AI Studio, then paste it in Settings.");
    const b = el("button", "btn", "Open Settings");
    b.onclick = () => chrome.runtime.sendMessage({ type: "mc-options" });
    s.append(document.createElement("br"), b);
    chat.append(s);
  }

  function place(p, r) {
    const W = 400, H = Math.min(560, innerHeight * 0.8), m = 14;
    let left = r.x + r.w + m, top = r.y;
    if (left + W > innerWidth - m) left = r.x - W - m;
    if (left < m) left = Math.max(m, Math.min(innerWidth - W - m, r.x + r.w / 2 - W / 2));
    top = Math.max(m, Math.min(innerHeight - H - m, top));
    p.style.left = left + "px"; p.style.top = top + "px";
  }

  function drag(p, handle) {
    handle.addEventListener("mousedown", (e) => {
      if (e.target.tagName === "BUTTON") return;
      const sx = e.clientX - p.offsetLeft, sy = e.clientY - p.offsetTop;
      const mv = (ev) => { p.style.left = ev.clientX - sx + "px"; p.style.top = ev.clientY - sy + "px"; };
      const up = () => { removeEventListener("mousemove", mv, true); removeEventListener("mouseup", up, true); };
      addEventListener("mousemove", mv, true); addEventListener("mouseup", up, true);
      e.preventDefault();
    });
  }

  // ---------- tiny safe markdown ----------
  function esc(s) { return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c])); }
  function inline(s) {
    return esc(s)
      .replace(/`([^`]+)`/g, "<code>$1</code>")
      .replace(/\*\*([^*]+)\*\*/g, "<b>$1</b>")
      .replace(/(^|[^*])\*([^*\s][^*]*)\*/g, "$1<i>$2</i>")
      .replace(/\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  }
  function md(src) {
    const lines = src.split("\n"); let html = "", list = null, code = null;
    const endList = () => { if (list) { html += `</${list}>`; list = null; } };
    for (const ln of lines) {
      if (/^```/.test(ln)) { if (code === null) { endList(); code = ""; } else { html += `<pre><code>${esc(code)}</code></pre>`; code = null; } continue; }
      if (code !== null) { code += ln + "\n"; continue; }
      let m;
      if ((m = ln.match(/^(#{1,4})\s+(.*)/))) { endList(); html += `<h3>${inline(m[2])}</h3>`; }
      else if ((m = ln.match(/^\s*[-*•]\s+(.*)/))) { if (list !== "ul") { endList(); html += "<ul>"; list = "ul"; } html += `<li>${inline(m[1])}</li>`; }
      else if ((m = ln.match(/^\s*\d+[.)]\s+(.*)/))) { if (list !== "ol") { endList(); html += "<ol>"; list = "ol"; } html += `<li>${inline(m[1])}</li>`; }
      else if (ln.trim() === "") { endList(); }
      else { endList(); html += `<p>${inline(ln)}</p>`; }
    }
    endList(); if (code !== null) html += `<pre><code>${esc(code)}</code></pre>`;
    return html;
  }

  chrome.runtime.onMessage.addListener((m) => { if (m && m.type === "mc-start") startSelect(m.shot); });
})();
