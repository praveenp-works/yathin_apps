const $ = (id) => document.getElementById(id);
chrome.storage.local.get("key").then(({ key }) => { if (key) $("key").value = key; });
$("save").onclick = async () => {
  const key = $("key").value.trim();
  const msg = $("msg");
  if (!key) { msg.className = "bad"; msg.textContent = "Paste your key first."; return; }
  msg.className = ""; msg.textContent = "Checking…";
  try {
    const r = await fetch("https://generativelanguage.googleapis.com/v1beta/models?pageSize=1", { headers: { "x-goog-api-key": key } });
    if (!r.ok) throw new Error();
    await chrome.storage.local.set({ key });
    msg.className = "ok"; msg.textContent = "Saved! Press Ctrl+Shift+Space on any website to start.";
  } catch (e) {
    msg.className = "bad"; msg.textContent = "That key didn't work. Check you copied all of it.";
  }
};
